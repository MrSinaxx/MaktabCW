from data_manager import DBManager
from core.models import User

db_config = {
    # TODO
}

manager = DBManager({'db_config':db_config})